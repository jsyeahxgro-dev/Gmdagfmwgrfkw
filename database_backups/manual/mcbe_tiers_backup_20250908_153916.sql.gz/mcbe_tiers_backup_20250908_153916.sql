--
-- PostgreSQL database dump
--

-- Dumped from database version 16.9 (84ade85)
-- Dumped by pg_dump version 16.9

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: players; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.players (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    skywars_tier text DEFAULT 'NR'::text NOT NULL,
    midfight_tier text DEFAULT 'NR'::text NOT NULL,
    uhc_tier text DEFAULT 'NR'::text NOT NULL,
    nodebuff_tier text DEFAULT 'NR'::text NOT NULL,
    bedfight_tier text DEFAULT 'NR'::text NOT NULL
);


ALTER TABLE public.players OWNER TO neondb_owner;

--
-- Data for Name: players; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.players (id, name, skywars_tier, midfight_tier, uhc_tier, nodebuff_tier, bedfight_tier) FROM stdin;
267ae5c0-8c7f-4fff-b1d1-1192a30e8eaa	D3j4411	MIDT1	NR	NR	NR	NR
378c195d-4a6d-46fc-8128-a5129697a4b6	Velfa1r	MIDT1	NR	NR	NR	NR
b5ef6eb7-6565-4199-928e-ea6054506f96	DR0IDv	LT1	NR	NR	NR	NR
1587d2c6-262c-4647-aeb6-6b957c5aa258	Torqueyckpio	LT1	NR	NR	NR	NR
2fb5ad6a-ce1b-4873-8358-13f412272cfb	Rivav0cals	LT1	NR	NR	NR	NR
bd08a76a-3728-4aa5-ae5e-82ef1ece09b6	ItzAaronHi	HT2	NR	NR	NR	NR
3712729d-2f80-4da4-915c-08ab63e74f73	zAmqni	MIDT2	NR	NR	NR	NR
e5ad9a75-f2bf-4e72-b028-4dd3b6fc85c3	Mikeyandroid	LT2	NR	NR	NR	NR
5c0367af-b005-4535-a493-b6d231ab86ae	TECHNOGRIZZ4350	LT2	NR	NR	NR	NR
69822912-a5b3-4c1b-968d-1fd134ce5d38	GK GAMER1155	LT2	NR	NR	NR	NR
879f2164-5aff-4058-89d9-6be3637db0e9	Astronery	LT2	NR	NR	NR	NR
20c7cfe4-9d00-42cc-9879-22962a350dab	RacezinN	LT2	NR	NR	NR	NR
b34b6d83-76d3-47b2-b158-c4867ebf4f22	ElectricHayden	HT3	NR	NR	NR	NR
db76618d-e411-49fb-843b-4b006fdf6563	FlamePvPs	HT3	NR	NR	NR	NR
65c5a5fc-2d77-49de-a855-dde975b2ae48	GLITCH BGLDS	MIDT3	NR	NR	NR	NR
ce924f4e-87aa-44b5-ba5c-012b38ec3d77	Tuanxipu	MIDT3	NR	NR	NR	NR
af272a03-9285-4c1d-a922-dae4e6dfd225	Santoshnew12	MIDT3	NR	NR	NR	NR
ed6bd766-7951-4ff1-b441-0deda671405b	Dr Clipsss	MIDT3	NR	NR	NR	NR
50d86d11-60ae-45ed-988b-490610063f8a	Dream58570	MIDT3	NR	NR	NR	NR
5a1088d2-da40-4f6b-a05b-d34f0d763407	DtierinPE	LT3	NR	NR	NR	NR
487c4ffe-5c32-40ed-90a0-a51acf69aa55	BU1LTDFRNT	LT3	NR	NR	NR	NR
401b12a6-8c3f-4a44-8087-5379eb7720ed	Y0urPh0b14MC	LT3	NR	NR	NR	NR
dfa7ed4c-c69e-4589-92fd-eefd74a97183	TdmbT	LT3	NR	NR	NR	NR
d652cd2c-e1ed-406e-8951-aafcad9b3bbb	SibertronX1	LT3	NR	NR	NR	NR
7d5e4bac-a04d-43be-8e8b-162d5989d71a	Zillvix	LT3	NR	NR	NR	NR
cec853fa-e32d-47d0-b9dc-02b6ba6917b9	qdoolz	LT3	NR	NR	NR	NR
d3c710f7-7445-40bb-948a-ebd0a7ebc8f0	Fawnyxgaming1	LT5	NR	NR	NR	NR
\.


--
-- Name: players players_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT players_pkey PRIMARY KEY (id);


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO neon_superuser WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON TABLES TO neon_superuser WITH GRANT OPTION;


--
-- PostgreSQL database dump complete
--

