--
-- PostgreSQL database dump
--

-- Dumped from database version 16.9 (84ade85)
-- Dumped by pg_dump version 16.9

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: players; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.players (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    skywars_tier text DEFAULT 'NR'::text NOT NULL,
    midfight_tier text DEFAULT 'NR'::text NOT NULL,
    uhc_tier text DEFAULT 'NR'::text NOT NULL,
    nodebuff_tier text DEFAULT 'NR'::text NOT NULL,
    bedfight_tier text DEFAULT 'NR'::text NOT NULL
);


ALTER TABLE public.players OWNER TO neondb_owner;

--
-- Data for Name: players; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.players (id, name, skywars_tier, midfight_tier, uhc_tier, nodebuff_tier, bedfight_tier) FROM stdin;
b6ff4f6e-aa86-42f7-b05a-2a0fa060caaf	D3j4411	HT1	HT1	HT2	NR	NR
fb892eec-0ec7-4b12-9ddd-0d3d75a004e1	Velfair	HT1	HT2	HT1	HT3	NR
47a871e4-dcad-4e35-9742-0ab8e96b7c5b	Torqueyckpio	MIDT1	HT2	HT3	NR	LT1
afc2b24a-c33c-46c9-a2d8-17efc43773f6	RivaV0cals	HT1	HT3	HT2	NR	NR
49bfcb72-2e49-4da9-a028-8aa11d5b24c8	ItzAaronHi	HT2	MIDT2	LT1	NR	NR
d7168481-e7c6-4bae-a08c-b0b13a6a5a8b	zAmqni	HT2	NR	MIDT1	HT3	NR
a0402ece-5b6e-4afb-b204-c5365a87b182	Mikeyandroid	MIDT2	HT3	LT2	NR	LT1
a44723d8-f728-4de4-af04-49554672f24c	EletricHayden	HT3	MIDT3	NR	NR	NR
3832c3b4-01c1-4d91-a043-9eb99ac1a150	FlamePvPs	MIDT3	LT2	LT3	NR	NR
74b4a0f5-b6fa-4bf8-9e9b-0bf8db51900c	ComicBiscuit778	LT1	LT4	NR	NR	NR
565f6651-b446-46c0-91d8-d412620ed5b8	EfrazBR	NR	NR	NR	LT1	LT3
e59e9a2f-e864-404b-9feb-f11f2fa919ac	DR0IDv	MIDT1	HT1	LT3	HT3	HT1
f36f627b-9939-4364-8415-7534ff9f2ad4	Virz	MIDT3	NR	NR	NR	NR
\.


--
-- Name: players players_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT players_pkey PRIMARY KEY (id);


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO neon_superuser WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON TABLES TO neon_superuser WITH GRANT OPTION;


--
-- PostgreSQL database dump complete
--

